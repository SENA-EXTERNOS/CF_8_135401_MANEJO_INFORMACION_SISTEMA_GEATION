function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bghDs4LoMY":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}


function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ngJ2ry6ar6":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

